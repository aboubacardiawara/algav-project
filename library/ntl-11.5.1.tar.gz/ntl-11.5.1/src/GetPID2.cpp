
unsigned long _ntl_GetPID()
{
   return 0;
}

