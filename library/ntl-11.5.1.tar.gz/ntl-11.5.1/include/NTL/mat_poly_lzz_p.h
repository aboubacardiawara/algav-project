
#ifndef NTL_mat_poly_zz_p__H
#define NTL_mat_poly_zz_p__H

#include "./mat_lzz_p.h"
#include "./lzz_pX.h"

NTL_OPEN_NNS

void CharPoly(zz_pX& f, const mat_zz_p& M);

NTL_CLOSE_NNS


#endif
